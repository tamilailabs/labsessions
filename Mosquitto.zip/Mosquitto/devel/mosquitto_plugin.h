#include <mosquitto/broker_plugin.h>
#warning "Please replace '#include <broker_plugin.h> with #include <mosquitto.h>"
